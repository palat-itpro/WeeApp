import {Component} from '@angular/core';

@Component({
    templateUrl: './display.component.html'
})
export class DisplayComponent {}
