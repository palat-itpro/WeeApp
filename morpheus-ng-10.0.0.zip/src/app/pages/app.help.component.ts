import { Component } from '@angular/core';

@Component({
    templateUrl: './app.help.component.html',
})
export class AppHelpComponent {
    text: any;

}
